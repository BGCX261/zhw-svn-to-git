/*
Script: piechart.js

Dependencies:
	mootools-beta-1.2b2.js
	excanvas-compressed.js

Author:
	Greg Houston, <http://greghoustondesign.com/>

Credits:
	Based on Stoyan Stefanov's Canvas Pie:< http://www.phpied.com/canvas-pie/>
	Color algorithm inspired by Jim Bumgardner:<http://www.krazydad.com/makecolors.php>

License:
	MIT License, <http://en.wikipedia.org/wiki/MIT_License>	
	
Example Usage:
	
	<table class="pieChart">
    	<tr><th>Language  </th> <th>Value</th> </tr>
    	<tr><td>JavaScript</td> <td>100</td>   </tr>
    	<tr><td>CSS       </td> <td>200</td>   </tr>
    	<tr><td>HTML      </td> <td>180</td>   </tr>
    	<tr><td>PHP       </td> <td>50 </td>   </tr>
    	<tr><td>MySQL     </td> <td>320</td>   </tr>
    	<tr><td>Apache    </td> <td>90 </td>   </tr>
    	<tr><td>Linux     </td> <td>30 </td>   </tr>
	</table>

*/


var PieChart = new Class({
	options: {
		pieChartRadius: 100 // Half the width of your pie chart		
	},
	initialize: function(options){
		this.setOptions(options);
		
		// Initialize variables
		this.pieChartRadius = this.options.pieChartRadius;	
		this.pieChartDiameter = this.pieChartRadius * 2;
		this.pieVertices = 12; // Does not include the center vertex
		this.arcIncrementMultiplier = 1 / this.pieVertices;
		this.index = 0;
		this.tableIndex = 1;
		this.areaIndex = 1;
		this.container = '';
		this.tableNew = '';
		
		// Run Methods
		$$('.pieChart').each(function(el){
			this.insertElements(el);
			this.makePieChart(el);
		}.bind(this));
	},
	insertElements: function(el){
	
		this.container = new Element('div', {
			id: 'pieChartContainer' + this.tableIndex
		}).injectBefore($(el)).addClass('pieChartContainer');
		
		this.tableNew = el.clone().injectBottom(this.container);
		el.dispose();			
	
		new Element('div', {
			id: 'pieChartWrapper' + this.tableIndex
		}).injectTop(this.container).addClass('pieChartWrapper');
		
		var canvas = new Element('canvas', {
			id: 'canvas' + this.tableIndex,
			width: this.pieChartDiameter,
			height: this.pieChartDiameter
		}).injectInside(this.container.getElement('.pieChartWrapper')).addClass('pieChartCanvas');
		
		// Dynamically initialize canvas using excanvas. This is only required by IE
		if (Browser.Engine.trident) {
			G_vmlCanvasManager.initElement(canvas);
		}	

		new Element('map', {		
			id: 'pieChartMap' + this.tableIndex,
			name: 'pieChartMap' + this.tableIndex
		}).injectBottom(this.container).addClass('pieChartMap');

		new Asset.image('images/spacer.gif', {
			alt: '',
			usemap: '#pieChartMap' + this.tableIndex,
			width: this.pieChartDiameter,
			height: this.pieChartDiameter
		}).injectInside(this.container.getElement('.pieChartWrapper')).setStyles({
				'width': this.pieChartDiameter,
				'height': this.pieChartDiameter
			});
		
		new Element('div').injectBottom(this.container).addClass('clear');
	
	},
	makePieChart: function(){

	   	///// STEP 0 - setup

    	// source data table and canvas tag
    	var data_table = this.tableNew;
    	var canvas = this.container.getElement('.pieChartCanvas');
    	var td_index = 1; // which TD contains the data
    	var td_label_index = 0; // which TD contains the label	

    	///// STEP 1 - Get the data

    	// get the data[] from the table
    	var tds, data = [], color, colors = [], label, labels = [], value = 0, values = [], total = 0;
    	var trs = data_table.getElementsByTagName('tr'); // all TRs
    	for (var i = 0; i < trs.length; i++) {
        	tds = trs[i].getElementsByTagName('td'); // all TDs

			if (tds.length === 0) continue; //  no TDs here, move on

        	// get the value, update total
			label = tds[td_label_index].innerHTML;
			labels[colors.length] = label;
        	value  = parseFloat(tds[td_index].innerHTML);
			values[colors.length] = value;
        	data[data.length] = value;
        	total += value;

        	// random color
        	color = this.getColor(i, trs.length);
        	colors[colors.length] = color; // save for later
        	trs[i].style.backgroundColor = color; // color this TR
    	}

    	///// STEP 2 - Draw pie on canvas

    	// get canvas context, determine radius and center
    	var ctx = canvas.getContext('2d');

    	// loop the data[]
		var tableLength = colors.length;
    	for (piece=0; piece < tableLength; piece++) {

        	var thisvalue = data[piece] / total;		
			var arcStartAngle = Math.PI * (- 0.5 + 2 * this.index);
			var arcEndAngle = Math.PI * (- 0.5 + 2 * (this.index + thisvalue));		

			ctx.beginPath();
			ctx.moveTo(this.pieChartRadius, this.pieChartRadius); // center of the pie
			ctx.arc(  // draw next arc
            	this.pieChartRadius,
            	this.pieChartRadius,
            	this.pieChartRadius,
            	arcStartAngle, // -0.5 sets set the start to be top
            	arcEndAngle,
            	false
        	);
        	ctx.closePath();		
        	ctx.fillStyle = colors[piece];    // color
        	ctx.fill();
		
			// Draw the same thing again to draw stroke properly in IE
			ctx.lineWidth = 1;
        	ctx.beginPath();
        	ctx.moveTo(this.pieChartRadius, this.pieChartRadius); // center of the pie

        	ctx.arc(  // draw next arc
            	this.pieChartRadius,
            	this.pieChartRadius,
            	this.pieChartRadius,
            	arcStartAngle, // -0.5 sets set the start to be top
            	arcEndAngle,
            	false
        	);
        	ctx.closePath();		
			ctx.strokeStyle = "#FFF";
			ctx.stroke();

    		///// STEP 3 - Draw pie on image map
		
			var arcIncrement = (arcEndAngle - arcStartAngle) * this.arcIncrementMultiplier;
		
			var xx = this.pieChartRadius + Math.round(Math.cos(arcStartAngle) * this.pieChartRadius);
			var yy = this.pieChartRadius + Math.round(Math.sin(arcStartAngle) * this.pieChartRadius);
			
			var coord = [];
			var coordIndex = 1;
						
			for (i = 0; i < ((this.pieVertices * 2) - 2); i = i+2) {				 			
				coord[i] = this.pieChartRadius + Math.round(Math.cos(arcStartAngle + arcIncrement * coordIndex) * this.pieChartRadius);				
				coord[i+1] = this.pieChartRadius + Math.round(Math.sin(arcStartAngle + arcIncrement * coordIndex) * this.pieChartRadius);
				coordIndex++;			
			}
		
			var xxEnd = this.pieChartRadius + Math.round(Math.cos(arcEndAngle) * this.pieChartRadius);
			var yyEnd = this.pieChartRadius + Math.round(Math.sin(arcEndAngle) * this.pieChartRadius);			

			var myArea = 'area' + this.tableIndex + '-' + piece;
		
			new Element('area', {
				'id': myArea ,
				'shape': 'poly',
				'coords': this.pieChartRadius + ',' + this.pieChartRadius + ',' + + xx + ',' + yy + ',' + coord.join(',') +  ',' + xxEnd + ',' + yyEnd,
				'title': labels[piece] + ' :: ' + values[piece]
			}).injectInside(this.container.getElement('.pieChartMap'));

    		///// STEP 4 - Add Tooltips
	
			new Tips($(myArea), {
				showDelay: 10,
				hideDelay: 10
			});	    	

        	this.index += thisvalue; // increment progress tracker
    	}

	this.tableIndex++;
    	
	},
	getColor: function(i, totalSteps){ // utility - color generator
		var colori = i * 100 / totalSteps;		
		var frequency = Math.PI*2 / totalSteps;
		var center = 190;
		var amplitude = 60;
        var rgb = [];	
		rgb[0]   = Math.round(Math.sin(frequency * i + 0) * amplitude + center);
		rgb[1] = Math.round(Math.sin(frequency * i + 2) * amplitude + center);
		rgb[2]  = Math.round(Math.sin(frequency * i + 4) * amplitude + center);	
		return 'rgb(' + rgb.join(',') + ')';
	}	
});
PieChart.implement(new Options);

window.addEvent('load', function(){
		new PieChart();
});